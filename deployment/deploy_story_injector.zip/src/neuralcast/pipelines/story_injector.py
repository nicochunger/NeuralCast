"""Generate and inject a narrated story after an upcoming AzuraCast track."""

from __future__ import annotations

import argparse
import base64
import datetime as dt
import os
import pathlib
import re
import shutil
import time
import warnings
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence

import requests
from dotenv import load_dotenv
from requests import Response
from urllib3.exceptions import InsecureRequestWarning

from neuralcast.config import ASSETS_ROOT
from neuralcast.playlists.utils import sanitize_filename_component
from neuralcast.services.openai_client import (
    gemini_text_completion,
    synthesize_speech,
)
from neuralcast.stories.variation import (
    DELIVERY_VARIANTS,
    NARRATIVE_VARIANTS,
    DeliveryVariant,
    NarrativeVariant,
    compute_story_seed,
    iter_recent_ids,
    load_style_history,
    PREFERRED_PAIRINGS,
    save_style_history,
    select_variants_with_pairing,
    update_style_history,
)

STORY_ROOT = ASSETS_ROOT / "stories"
STORY_PROMPT_PATH = STORY_ROOT / "story_prompt.md"
TTS_INSTRUCTIONS_PATH = STORY_ROOT / "tts_story_instructions.md"
STORY_OUTPUT_DIR = STORY_ROOT / "snippets"
STYLE_HISTORY_PATH = STORY_ROOT / "style_history.json"
STYLE_HISTORY_MAX_ENTRIES = 60
NARRATIVE_AVOID_WINDOW = 3
DELIVERY_AVOID_WINDOW = 3


@dataclass
class UpcomingTrack:
    queue_id: str
    song_id: Optional[str]
    artist: str
    title: str
    starts_at: Optional[dt.datetime]
    duration: Optional[int]
    raw: Dict


@dataclass
class StoryAssets:
    text_path: pathlib.Path
    audio_path: pathlib.Path
    story_text: str
    remote_path: str


def extract_current_listeners(now_playing_payload: Dict) -> Optional[int]:
    """Extract the current listener count from AzuraCast's now-playing payload."""
    listener_fields: List[Optional[int]] = []
    if isinstance(now_playing_payload, dict):
        direct_listeners = now_playing_payload.get("listeners")
        if isinstance(direct_listeners, dict):
            listener_fields.append(direct_listeners.get("current"))

        now_playing_block = now_playing_payload.get("now_playing")
        if isinstance(now_playing_block, dict):
            block_listeners = now_playing_block.get("listeners")
            if isinstance(block_listeners, dict):
                listener_fields.append(block_listeners.get("current"))

    for candidate in listener_fields:
        try:
            if candidate is not None:
                return int(candidate)
        except (TypeError, ValueError):
            continue
    return None


class AzuraCastClient:
    """Thin AzuraCast API helper focused on queue manipulation."""

    def __init__(self, base_url: str, api_key: str, verify_tls: bool = False):
        self.base_url = base_url.rstrip("/")
        self.verify_tls = verify_tls
        self.session = requests.Session()
        self.session.headers.update({"X-API-Key": api_key})

        if not verify_tls:
            warnings.filterwarnings("ignore", category=InsecureRequestWarning)

    def _build_url(self, path: str) -> str:
        return f"{self.base_url}/{path.lstrip('/')}"

    def _request(self, method: str, path: str, **kwargs) -> Response:
        kwargs.setdefault("timeout", 15)
        kwargs.setdefault("verify", self.verify_tls)
        response = self.session.request(
            method=method, url=self._build_url(path), **kwargs
        )
        response.raise_for_status()
        return response

    def get_stations(self) -> List[Dict]:
        return self._request("GET", "/api/stations").json()

    def get_now_playing(self, station: str) -> Dict:
        try:
            return self._request("GET", f"/api/nowplaying/{station}").json()
        except requests.HTTPError as exc:  # fallback to aggregate endpoint
            if exc.response is not None and exc.response.status_code == 404:
                payload = self._request("GET", "/api/nowplaying").json()
                for station_payload in payload:
                    shortcode = station_payload.get("station", {}).get("shortcode")
                    if shortcode == station:
                        return station_payload
            raise

    def get_upcoming_queue(self, station: str) -> List[Dict]:
        payload = self._request("GET", f"/api/station/{station}/queue").json()
        if isinstance(payload, dict) and "data" in payload:
            data = payload.get("data") or []
            return data if isinstance(data, list) else []
        if isinstance(payload, list):
            return payload
        return []

    def upload_media(
        self, station: str, file_path: pathlib.Path, remote_path: Optional[str] = None
    ) -> Dict:
        destination = remote_path or file_path.name
        payload = {
            "path": destination,
            "file": base64.b64encode(file_path.read_bytes()).decode("ascii"),
        }
        try:
            response = self._request(
                "POST",
                f"/api/station/{station}/files",
                json=payload,
            )
        except requests.HTTPError as exc:
            detail = ""
            if exc.response is not None:
                try:
                    detail = exc.response.json()
                except Exception:  # noqa: BLE001
                    detail = exc.response.text
            raise RuntimeError(
                f"Failed to upload media {file_path.name} to station {station}: {detail}"
            ) from exc
        return response.json()

    def list_media_files(self, station: str) -> List[Dict]:
        return self._request("GET", f"/api/station/{station}/files").json()

    def delete_media_file(self, station: str, media_id: int) -> Dict:
        return self._request("DELETE", f"/api/station/{station}/file/{media_id}").json()

    def send_telnet_command(self, station_id: int, command: str) -> Dict:
        payload = {"command": command}
        response = self._request(
            "PUT",
            f"/api/admin/debug/station/{station_id}/telnet",
            json=payload,
        )
        return response.json()


def parse_upcoming_queue(queue_payload: Sequence[Dict]) -> List[UpcomingTrack]:
    parsed: List[UpcomingTrack] = []
    for entry in queue_payload:
        queue_id = entry.get("id") or entry.get("queue_id") or entry.get("unique_id")
        song = entry.get("song") or {}
        artist = song.get("artist") or entry.get("artist") or ""
        title = song.get("title") or entry.get("title") or ""
        song_id = song.get("id") or entry.get("song_id")

        starts_at_raw = (
            entry.get("play_at") or entry.get("played_at") or entry.get("cued_at")
        )
        starts_at = None
        if isinstance(starts_at_raw, (int, float)):
            starts_at = dt.datetime.fromtimestamp(starts_at_raw, tz=dt.timezone.utc)
        elif isinstance(starts_at_raw, str):
            try:
                starts_at = dt.datetime.fromisoformat(
                    starts_at_raw.replace("Z", "+00:00")
                )
            except ValueError:
                starts_at = None

        duration = None
        if "duration" in entry:
            try:
                duration = int(entry["duration"])
            except (TypeError, ValueError):
                duration = None
        elif "length" in entry:
            try:
                duration = int(entry["length"])
            except (TypeError, ValueError):
                duration = None

        if not queue_id:
            fallback_candidates = [
                song_id,
                entry.get("media_id"),
                entry.get("played_at"),
                entry.get("cued_at"),
            ]
            for candidate in fallback_candidates:
                if candidate:
                    queue_id = str(candidate)
                    break
        if not queue_id:
            queue_id = f"entry-{len(parsed)}"

        if not title:
            continue

        parsed.append(
            UpcomingTrack(
                queue_id=queue_id,
                song_id=song_id,
                artist=artist,
                title=title,
                starts_at=starts_at,
                duration=duration,
                raw=entry,
            )
        )
    return parsed


def tracks_equal(a: UpcomingTrack, b: UpcomingTrack) -> bool:
    if a.queue_id and b.queue_id and a.queue_id == b.queue_id:
        return True
    if a.song_id and b.song_id and a.song_id == b.song_id:
        return True
    return (a.artist or "").strip().lower() == (b.artist or "").strip().lower() and (
        a.title or ""
    ).strip().lower() == (b.title or "").strip().lower()


def find_following_track(
    selected: UpcomingTrack,
    current_track_candidate: Optional[UpcomingTrack],
    upcoming_tracks: Sequence[UpcomingTrack],
) -> Optional[UpcomingTrack]:
    if current_track_candidate is not None and tracks_equal(
        selected, current_track_candidate
    ):
        return upcoming_tracks[0] if upcoming_tracks else None

    for idx, track in enumerate(upcoming_tracks):
        if tracks_equal(selected, track):
            if idx + 1 < len(upcoming_tracks):
                return upcoming_tracks[idx + 1]
            return None
    return None


def cleanup_story_text(raw: str) -> str:
    """Strip URLs, Markdown link remnants, and reference markers from generated copy."""
    text = re.sub(r"\[([^\]]+)\]\(\s*https?://[^\)]+\)", r"\1", raw)
    text = re.sub(r"https?://\S+", "", text)
    text = re.sub(r"\[\s*\d+\s*\]", "", text)
    text = re.sub(r"\[[^\]]+\]", "", text)
    text = re.sub(
        r"\(\s*(?:[a-z][a-z0-9-]*\.)+[a-z]{2,}\s*\)", "", text, flags=re.IGNORECASE
    )
    text = re.sub(r"\b(?:[a-z][a-z0-9-]*\.)+[a-z]{2,}\b", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\(\s*\)", "", text)
    text = text.replace("((", "(").replace("))", ")")
    cleaned_lines = [re.sub(r"\s{2,}", " ", line).strip() for line in text.splitlines()]
    cleaned = "\n".join(line for line in cleaned_lines if line)
    return cleaned.strip()


def generate_story_text(
    artist: str,
    title: str,
    station: str,
    next_artist: str,
    next_title: str,
    narrative_variant: NarrativeVariant,
) -> str:
    template = STORY_PROMPT_PATH.read_text(encoding="utf-8")
    prompt = template
    replacements = {
        "ARTIST": artist,
        "TITLE": title,
        "STATION": station,
        "NEXT_ARTIST": next_artist,
        "NEXT_TITLE": next_title,
    }
    for key, value in replacements.items():
        prompt = prompt.replace(f"[{key}]", value)

    variant_replacements = {
        "INTRO_STYLE": narrative_variant.intro_instruction,
        "BODY_STYLE": narrative_variant.body_instruction,
        "OUTRO_STYLE": narrative_variant.outro_instruction,
        "FILLER_WORDS": narrative_variant.filler_words,
    }
    for key, value in variant_replacements.items():
        prompt = prompt.replace(f"{{{{{key}}}}}", value)

    story = gemini_text_completion(prompt=prompt)
    return cleanup_story_text(story)


def synthesize_story_audio(
    story_text: str,
    outfile: pathlib.Path,
    delivery_variant: DeliveryVariant,
) -> None:
    tts_template = TTS_INSTRUCTIONS_PATH.read_text(encoding="utf-8").strip()
    instructions = tts_template
    delivery_replacements = {
        "DELIVERY_VARIATION": delivery_variant.delivery_instruction,
        "PACE_ADJUSTMENT": delivery_variant.pace_instruction,
        "DELIVERY_ADDITIONAL": delivery_variant.additional_prompts,
    }
    for key, value in delivery_replacements.items():
        instructions = instructions.replace(f"{{{{{key}}}}}", value)

    synthesize_speech(
        text=story_text,
        outfile=str(outfile),
        instructions=instructions,
    )


def write_story_text_file(story_text: str, outfile: pathlib.Path) -> None:
    outfile.write_text(story_text + "\n", encoding="utf-8")


def ensure_story_assets(
    station_slug: str,
    artist: str,
    title: str,
    story_text: str,
    delivery_variant: DeliveryVariant,
) -> StoryAssets:
    safe_artist = sanitize_filename_component(artist).replace("'", "")
    safe_title = sanitize_filename_component(title).replace("'", "")
    timestamp = dt.datetime.now()
    date_str = timestamp.strftime("%Y-%m-%d")
    station_dir = STORY_OUTPUT_DIR / station_slug
    target_dir = station_dir / date_str
    base_name = f"Story_{safe_artist}_{safe_title}_{timestamp.strftime('%H%M%S')}"
    audio_path = target_dir / f"{base_name}.mp3"
    text_path = target_dir / f"{base_name}.txt"

    target_dir.mkdir(parents=True, exist_ok=True)
    write_story_text_file(story_text, text_path)
    synthesize_story_audio(story_text, audio_path, delivery_variant)

    return StoryAssets(
        text_path=text_path,
        audio_path=audio_path,
        story_text=story_text,
        remote_path="/".join(["AI Stories", date_str, f"{base_name}.mp3"]),
    )


def derive_media_id(upload_response: Dict, file_name: str) -> Optional[str]:
    if not upload_response:
        return None
    if "data" in upload_response:
        data = upload_response["data"]
        if isinstance(data, dict):
            if "media" in data and isinstance(data["media"], dict):
                media = data["media"]
                return str(
                    media.get("id")
                    or media.get("media_id")
                    or media.get("unique_id")
                    or ""
                )
            for key in ("id", "media_id", "unique_id", "song_id"):
                if key in data and data[key]:
                    return str(data[key])
        if isinstance(data, list):
            for item in data:
                candidate = derive_media_id(item, file_name)
                if candidate:
                    return candidate
    for key in ("id", "media_id", "song_id", "unique_id"):
        if key in upload_response and upload_response[key]:
            return str(upload_response[key])

    meta = upload_response.get("meta") if isinstance(upload_response, dict) else None
    if isinstance(meta, dict):
        for key in ("id", "media_id", "unique_id"):
            if key in meta and meta[key]:
                return str(meta[key])

    message = (
        upload_response.get("message") if isinstance(upload_response, dict) else None
    )
    if message:
        print(f"Upload response message: {message}")
    print(
        f"Warning: Could not determine media ID from upload response; manual queueing may be required. "
        f"Response keys: {list(upload_response.keys())}"
    )
    return None


def escape_annotation_value(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def build_request_command(
    media_full_path: str,
    story_artist: str,
    story_title: str,
    duration: Optional[int],
) -> str:
    annotations = [
        f'title="{escape_annotation_value(story_title)}"',
        f'artist="{escape_annotation_value(story_artist)}"',
    ]
    if duration is not None and duration > 0:
        annotations.append(f'duration="{duration}"')
    annotation_block = ",".join(annotations)
    return f"requests.push annotate:{annotation_block}:{media_full_path}"


def is_song_match(song_payload: Dict, track: UpcomingTrack) -> bool:
    if not song_payload:
        return False
    payload_song_id = song_payload.get("id")
    if payload_song_id and track.song_id and payload_song_id == track.song_id:
        return True
    payload_artist = (song_payload.get("artist") or "").strip().lower()
    payload_title = (song_payload.get("title") or "").strip().lower()
    return (
        payload_artist == (track.artist or "").strip().lower()
        and payload_title == (track.title or "").strip().lower()
    )


def extract_telnet_response(log_payload: Dict) -> Optional[str]:
    logs = log_payload.get("logs")
    if not isinstance(logs, list):
        return None
    for entry in reversed(logs):
        context = entry.get("context")
        if not isinstance(context, dict):
            continue
        response_lines = context.get("response")
        if isinstance(response_lines, list) and response_lines:
            return response_lines[-1]
    return None


def wait_for_track_and_inject(
    client: AzuraCastClient,
    station_slug: str,
    station_id: Optional[int],
    target_track: UpcomingTrack,
    telnet_command: str,
    lead_seconds: int,
    timeout_seconds: int,
    poll_interval: int,
) -> Optional[str]:
    if station_id is None:
        raise RuntimeError("Station ID is required to send telnet commands.")

    deadline = dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=timeout_seconds)
    track_detected = False
    pushed_request_id: Optional[str] = None

    if lead_seconds > 0:
        print(
            "Note: inject_lead_seconds is ignored; story will be queued as soon as the song starts."
        )

    print(
        f"Waiting for target song '{target_track.artist} - {target_track.title}' to start playing..."
    )
    while dt.datetime.now(dt.timezone.utc) < deadline:
        status = client.get_now_playing(station_slug)
        now_payload = status.get("now_playing") or {}
        song_payload = now_payload.get("song") or {}
        remaining = now_payload.get("remaining")

        if is_song_match(song_payload, target_track):
            track_detected = True
            if remaining is not None:
                print(f"Target song playing; remaining time: {remaining}s")
            print("Queuing story via requests.push...")
            response = client.send_telnet_command(station_id, telnet_command)
            pushed_request_id = extract_telnet_response(response)
            break
        elif track_detected:
            print(
                "Target song finished earlier than expected; queuing story immediately..."
            )
            response = client.send_telnet_command(station_id, telnet_command)
            pushed_request_id = extract_telnet_response(response)
            break

        time.sleep(max(1, poll_interval))

    if pushed_request_id is None and not track_detected:
        raise RuntimeError(
            f"Timed out waiting for track '{target_track.artist} - {target_track.title}' to play."
        )

    return pushed_request_id


def cleanup_local_stories(station_slug: str, keep_days: int) -> None:
    if keep_days <= 0:
        return

    base_dir = STORY_OUTPUT_DIR / station_slug
    if not base_dir.exists():
        return

    cutoff = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=keep_days)
    cutoff_date = cutoff.date()
    date_dir_pattern = re.compile(r"^\d{4}-\d{2}-\d{2}$")
    for file_path in base_dir.rglob("*"):
        if file_path.is_file() and file_path.suffix.lower() in {".mp3", ".txt"}:
            try:
                file_mtime = dt.datetime.fromtimestamp(
                    file_path.stat().st_mtime, tz=dt.timezone.utc
                )
            except (OSError, ValueError):
                continue
            if file_mtime < cutoff:
                try:
                    file_path.unlink(missing_ok=True)
                except OSError:
                    print(f"Warning: failed to remove local story file {file_path}")

    # Remove dated directories once they fall outside the retention window
    for dir_path in base_dir.iterdir():
        if dir_path.is_dir() and date_dir_pattern.match(dir_path.name):
            try:
                dir_date = dt.datetime.strptime(dir_path.name, "%Y-%m-%d").date()
            except ValueError:
                continue
            if dir_date < cutoff_date:
                try:
                    shutil.rmtree(dir_path)
                except OSError:
                    print(f"Warning: failed to remove dated directory {dir_path}")

    # Remove empty directories (but keep the station root)
    for dir_path in sorted(
        base_dir.rglob("*"), key=lambda p: len(str(p)), reverse=True
    ):
        if dir_path == base_dir or not dir_path.is_dir():
            continue
        try:
            next(dir_path.iterdir())
        except StopIteration:
            try:
                dir_path.rmdir()
            except OSError:
                pass


def cleanup_remote_stories(
    client: AzuraCastClient, station_slug: str, keep_days: int
) -> None:
    if keep_days <= 0:
        return

    cutoff = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=keep_days)
    cutoff_ts = cutoff.timestamp()
    prefix = "AI Stories/"

    try:
        media_files = client.list_media_files(station_slug)
    except Exception as exc:  # noqa: BLE001
        print(f"Warning: unable to list remote media files for cleanup: {exc}")
        return

    for entry in media_files:
        path = entry.get("path") or ""
        if not path.startswith(prefix):
            continue
        mtime = entry.get("mtime")
        media_id = entry.get("id") or entry.get("media_id")
        if media_id is None or mtime is None:
            continue
        try:
            if float(mtime) >= cutoff_ts:
                continue
        except (TypeError, ValueError):
            continue
        try:
            client.delete_media_file(station_slug, int(media_id))
            print(f"Deleted remote story file '{path}' (media_id={media_id})")
        except Exception as exc:  # noqa: BLE001
            print(
                f"Warning: failed to delete remote story file '{path}' (media_id={media_id}): {exc}"
            )


def run(args: argparse.Namespace) -> None:
    load_dotenv()
    api_key = os.getenv("AZURACAST_API_KEY")
    if not api_key:
        raise RuntimeError("AZURACAST_API_KEY is not set in the environment.")

    base_url = args.base_url.rstrip("/")
    client = AzuraCastClient(
        base_url=base_url, api_key=api_key, verify_tls=args.verify_tls
    )

    stations = client.get_stations()
    station = None
    for station_entry in stations:
        shortcode = station_entry.get("shortcode") or station_entry.get(
            "station_short_name"
        )
        if shortcode == args.station:
            station = station_entry
            break
    if station is None:
        available = ", ".join(
            station_entry.get("shortcode", "?") for station_entry in stations
        )
        raise RuntimeError(
            f"Station '{args.station}' not found. Available: {available}"
        )

    print(f"Using station '{args.station}' ({station.get('name', 'unknown name')}).")

    now_playing_payload = client.get_now_playing(args.station)
    current_np_entry = now_playing_payload.get("now_playing") or {}
    current_song = current_np_entry.get("song") or {}
    current_remaining = current_np_entry.get("remaining")
    current_duration = current_np_entry.get("duration")

    print(
        f"Now playing: {current_song.get('artist', 'Unknown Artist')} - {current_song.get('title', 'Unknown Title')}"
    )

    listener_count = extract_current_listeners(now_playing_payload)
    if listener_count is None:
        print("Current listeners: unavailable in now-playing payload.")
    else:
        print(f"Current listeners: {listener_count}")

    if args.min_listeners > 0:
        if listener_count is None:
            print(
                f"Unable to determine listener count and --min-listeners is set to {args.min_listeners}; skipping story injection."
            )
            return
        if listener_count < args.min_listeners:
            print(
                f"Only {listener_count} listener(s) connected (< {args.min_listeners} required); skipping story injection."
            )
            return

    current_track_candidate: Optional[UpcomingTrack] = None
    if (
        current_song
        and current_song.get("artist")
        and current_song.get("title")
        and current_remaining is not None
        and current_remaining >= args.current_min_remaining
    ):
        current_track_candidate = UpcomingTrack(
            queue_id=current_song.get("id") or "now-playing",
            song_id=current_song.get("id"),
            artist=current_song.get("artist", ""),
            title=current_song.get("title", ""),
            starts_at=None,
            duration=int(current_duration) if current_duration is not None else None,
            raw={"source": "now_playing", "remaining": current_remaining},
        )
        print(
            f"Including current track for selection (remaining {current_remaining}s)."
        )

    raw_queue = client.get_upcoming_queue(args.station)
    upcoming_tracks = parse_upcoming_queue(raw_queue)
    if not upcoming_tracks and current_track_candidate is None:
        raise RuntimeError("No upcoming tracks found in station queue.")

    if current_track_candidate is not None:
        selected_track = current_track_candidate
        print("Using the currently playing song for the story selection.")
    elif upcoming_tracks:
        selected_track = upcoming_tracks[0]
        print("Current song is not eligible; using the next queued song.")
    else:
        raise RuntimeError("No tracks available to choose from.")
    print(
        f"Selected upcoming song: {selected_track.artist} - {selected_track.title} (queue_id={selected_track.queue_id})"
    )
    if selected_track.raw.get("source") == "now_playing":
        print("Story will play immediately after the current song.")
    else:
        print("Story will play after the selected track.")

    following_track = find_following_track(
        selected_track, current_track_candidate, upcoming_tracks
    )
    if following_track is None:
        raise RuntimeError(
            "Failed to determine which song follows the selected track; cannot craft segue."
        )
    print(
        f"Story will introduce the next song: {following_track.artist} - {following_track.title}."
    )

    station_display_name = (station.get("name") or args.station).strip()
    if args.station.lower() == "neuralforge":
        station_display_name = "NéuralForsh"

    story_seed = compute_story_seed(
        station=args.station,
        artist=selected_track.artist,
        title=selected_track.title,
        next_artist=following_track.artist,
        next_title=following_track.title,
    )
    history = load_style_history(STYLE_HISTORY_PATH)
    narrative_recent = list(iter_recent_ids(history, args.station, "narrative_id"))
    delivery_recent = list(iter_recent_ids(history, args.station, "delivery_id"))
    (
        narrative_variant,
        delivery_variant,
        chosen_pair,
    ) = select_variants_with_pairing(
        seed=story_seed,
        narrative_variants=NARRATIVE_VARIANTS,
        delivery_variants=DELIVERY_VARIANTS,
        pairings=PREFERRED_PAIRINGS,
        narrative_recent=narrative_recent,
        delivery_recent=delivery_recent,
        narrative_avoid_window=NARRATIVE_AVOID_WINDOW,
        delivery_avoid_window=DELIVERY_AVOID_WINDOW,
    )
    if chosen_pair:
        print(
            "Paired styles selected: "
            f"{narrative_variant.style_id} (narrative) + {delivery_variant.style_id} (delivery)"
        )
        print(f"Narrative description: {narrative_variant.description}")
        print(f"Delivery description: {delivery_variant.description}")
    else:
        print(
            f"Narrative style selected: {narrative_variant.style_id} — {narrative_variant.description}"
        )
        print(
            f"Delivery style selected: {delivery_variant.style_id} — {delivery_variant.description}"
        )

    story_text = generate_story_text(
        selected_track.artist,
        selected_track.title,
        station_display_name,
        following_track.artist,
        following_track.title,
        narrative_variant,
    )
    assets = ensure_story_assets(
        args.station,
        selected_track.artist,
        selected_track.title,
        story_text,
        delivery_variant,
    )
    print(f"Story text saved to {assets.text_path}")
    print(f"Story audio saved to {assets.audio_path}")

    if args.dry_run:
        print(
            "Dry-run mode enabled; skipping upload, queue injection, and style history update."
        )
        return

    upload_response = client.upload_media(
        args.station,
        assets.audio_path,
        remote_path=assets.remote_path,
    )
    media_id = derive_media_id(upload_response, assets.audio_path.name)
    if not media_id:
        raise RuntimeError("Failed to determine media ID for uploaded story audio.")
    print(f"Uploaded story MP3. Media ID: {media_id}")

    upload_path = (
        upload_response.get("path") if isinstance(upload_response, dict) else None
    )
    if not upload_path:
        raise RuntimeError(
            "Upload response missing storage path; cannot schedule playback."
        )

    full_media_path = f"/var/azuracast/stations/{args.station}/media/{upload_path}"
    story_duration = None
    if isinstance(upload_response, dict):
        length_val = upload_response.get("length")
        if length_val is not None:
            try:
                story_duration = int(float(length_val))
            except (TypeError, ValueError):
                story_duration = None

    telnet_command = build_request_command(
        media_full_path=full_media_path,
        story_artist="NeuralCast AI",
        story_title=f"Historia: {selected_track.title}",
        duration=story_duration,
    )
    try:
        request_id = wait_for_track_and_inject(
            client=client,
            station_slug=args.station,
            station_id=station.get("id"),
            target_track=selected_track,
            telnet_command=telnet_command,
            lead_seconds=args.inject_lead_seconds,
            timeout_seconds=args.inject_timeout,
            poll_interval=args.poll_interval,
        )
    except RuntimeError as exc:
        print(f"Error while waiting to queue story: {exc}")
        print(
            "The story MP3 is uploaded; you can queue it manually via Liquidsoap telnet with:\n"
            f"  {telnet_command}"
        )
        raise
    if request_id:
        print(f"Story queued via requests.push with request ID {request_id}.")
    else:
        print("Story queued via requests.push.")

    update_style_history(
        history=history,
        station=args.station,
        seed=story_seed,
        narrative_id=narrative_variant.style_id,
        delivery_id=delivery_variant.style_id,
        max_entries=STYLE_HISTORY_MAX_ENTRIES,
    )
    save_style_history(STYLE_HISTORY_PATH, history)

    cleanup_local_stories(args.station, args.keep_local_days)
    cleanup_remote_stories(client, args.station, args.keep_remote_days)


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate a short story about an upcoming AzuraCast song and inject it immediately after that song."
    )
    parser.add_argument(
        "--base-url",
        default=os.getenv("AZURACAST_BASE_URL", "https://192.168.1.226"),
        help="Base URL for the AzuraCast instance (default: %(default)s).",
    )
    parser.add_argument(
        "-s",
        "--station",
        default=os.getenv("AZURACAST_STATION", "neuralcast"),
        help="AzuraCast station shortcode (default: %(default)s).",
    )
    parser.add_argument(
        "--min-listeners",
        type=int,
        default=1,
        help="Require at least this many current listeners before generating or injecting a story (default: %(default)s; set to 0 to disable).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Generate story files locally without uploading or queuing them.",
    )
    parser.add_argument(
        "--verify-tls",
        action="store_true",
        help="Verify TLS certificates when calling AzuraCast (disabled by default for local/self-signed certs).",
    )
    parser.add_argument(
        "--inject-lead-seconds",
        type=int,
        default=15,
        help="(Deprecated) Previously delayed queueing; currently ignored because the story queues as soon as the song starts.",
    )
    parser.add_argument(
        "--inject-timeout",
        type=int,
        default=900,
        help="Maximum seconds to wait for the selected song to start playing (default: %(default)s).",
    )
    parser.add_argument(
        "--poll-interval",
        type=int,
        default=5,
        help="Seconds between successive now-playing polls (default: %(default)s).",
    )
    parser.add_argument(
        "--current-min-remaining",
        type=int,
        default=90,
        help="Use the current song only if it has at least this many seconds remaining (default: %(default)s).",
    )
    parser.add_argument(
        "--keep-local-days",
        type=int,
        default=3,
        help="Retain locally generated story assets for this many days (default: %(default)s).",
    )
    parser.add_argument(
        "--keep-remote-days",
        type=int,
        default=7,
        help="Retain uploaded story assets on AzuraCast for this many days (default: %(default)s).",
    )
    return parser


if __name__ == "__main__":
    args = build_arg_parser().parse_args()
    run(args)

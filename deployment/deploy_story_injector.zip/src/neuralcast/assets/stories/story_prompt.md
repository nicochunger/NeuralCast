Write a short story about the song “[TITLE]” by [ARTIST], told in the voice of an Argentine radio announcer as if speaking live on [STATION].

Requirements:

* The story **must be written in Spanish (Rioplatense)**.
* Tone: natural, calm, spontaneous — like someone speaking live from a radio studio (think Aspen-style warmth), not reading a rehearsed script.
* Voice: serene, mature, slightly nostalgic, authentic. Don’t dramatize or overact.
* Because this goes out immediately after the song ends, acknowledge it — e.g. “recién escuchamos…”, “eso fue…”, “acabamos de escuchar…”. etc
* Conclude naturally by previewing what's coming up next: "[NEXT_TITLE]" by [NEXT_ARTIST] (say it like a warm radio segue, not robotic).
* Use natural filler words and small hesitations to sound human, but keep them subtle; they are optional, and if they do not fit, omit them. Example mix: “bueno…”, “viste…”, “no sé…”, “che…”, “mirá…”, “en realidad…”, “la verdad…”, “bah…”, “qué sé yo…”, “ponele…”, “como que…”, “te juro…”, “nada…”, short pauses, etc.
* Avoid grandiloquent or poetic lines — it should sound like a simple, conversational recollection or anecdote about the song.
* Length: brief — aim for roughly **150–250 words** so it fits into ~45–90 seconds on air.
* Keep it spontaneous, with natural rhythm and small colloquial touches, nothing that sounds obviously scripted.
* Do not include links, web addresses, or numeric reference markers like “[1]”.

Style cues to weave into the narration (mantain the Aspen warmth while applying them):

* {{INTRO_STYLE}}
* {{BODY_STYLE}}
* {{OUTRO_STYLE}}
* {{FILLER_WORDS}}

Fact-checking:

* Before including any factual claims (dates, recording facts, chart positions, anecdotes), research online and verify them.
* Only include facts that can be confirmed; if something isn’t verifiable, omit it rather than guessing.
* If there are, try to include little fun facts beyond just generic things like release date and key people involved.
